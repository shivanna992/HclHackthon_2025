﻿using app_Scheduler.Data;
using app_Scheduler.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace app_Scheduler.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeeShiftPreferenceController : ControllerBase
    {
        private readonly AppDbContext _context;

        public EmployeeShiftPreferenceController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost("save")]
        public async Task<IActionResult> SaveData([FromBody] EmployeeShiftPreferenceDto dto)
        {
            if (dto == null)
            {
                return BadRequest("Invalid data.");
            }

            var entity = new EmployeeShiftPreference
            {
                Name = dto.Name,
                ContactNumber = dto.ContactNumber,
                Role = dto.Role,
                ShiftID = dto.ShiftID,
                ShiftPreference = dto.ShiftPreference,
                Roles = dto.Roles
            };

            _context.EmployeeShiftPreferences.Add(entity);
            await _context.SaveChangesAsync();

            return Ok(new { Message = "Data saved successfully", Data = entity });
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<EmployeeShiftPreferenceDto>>> GetAllStaff()
        {
            var staffList = await _context.EmployeeShiftPreferenceDto.ToListAsync();
            return Ok(staffList);
        }

        // GET: api/hospitalstaff/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<EmployeeShiftPreferenceDto>> GetStaffById(int id)
        {
            var staff = await _context.EmployeeShiftPreferenceDto.FindAsync(id);

            if (staff == null)
                return NotFound($"Staff with ID {id} not found.");

            return Ok(staff);
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateStaff(int id, [FromBody] EmployeeShiftPreferenceDto updatedStaff)
        {
            if (id != updatedStaff.ShiftID)
                return BadRequest("ID in URL and body do not match.");

            var existingStaff = await _context.EmployeeShiftPreferenceDto.FindAsync(id);
            if (existingStaff == null)
                return NotFound($"Staff with ID {id} not found.");

            // Update properties
            existingStaff.Name = updatedStaff.Name;
            existingStaff.Role = updatedStaff.Role;
            existingStaff.ShiftPreference = updatedStaff.ShiftPreference;

            // Save changes
            await _context.SaveChangesAsync();

            return NoContent(); // 204 - success, no body
        }
}


