﻿using app_Scheduler.Models;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;


namespace app_Scheduler.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
        {
        }

        public DbSet<EmployeeShiftPreference> EmployeeShiftPreferences { get; set; }
        public object EmployeeShiftPreferenceDto { get; internal set; }
    }
}
