﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace app_Scheduler.Models
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeShiftPreferenceDto : ControllerBase
    {
        public required string Name { get; set; }

        public required string ContactNumber { get; set; }

        public required string Role { get; set; }

        public required int ShiftID { get; set; }

        public required string ShiftPreference { get; set; }

        public required List<string> Roles { get; set; }
    }

}
