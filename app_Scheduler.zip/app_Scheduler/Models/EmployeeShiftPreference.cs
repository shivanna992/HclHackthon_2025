﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace app_Scheduler.Models
{
public class EmployeeShiftPreference
{
    public int Id { get; set; }  // Primary key for the database

    public required string Name { get; set; }

    public required string ContactNumber { get; set; }

    public required string Role { get; set; }

    public int ShiftID { get; set; }

    public required string ShiftPreference { get; set; }

    public required List<string> Roles { get; set; }
    }
}

